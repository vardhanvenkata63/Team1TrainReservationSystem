const objPeople = [
	
		 "sam",
		 "password25",
         "vardhan",
         "vardhan123",
         "neha",
         "neha123",
         "nayana",
         "nayana123",
         "gunasri",
         "gunasri123",
         "neelam",
         "neelam123",
         "harsha",
         "harsha123"
    
    
    

]        
          
           function login()
           {
            
               var username=document.getElementById('username').value
               var password=document.getElementById('password').value
               
                   if(objPeople.includes(username) && objPeople.includes(password))
                   {
                    
                       console.log(username + 'is logged in!!!!');
                       alert("login successfull")
                       window.open('UserHomePage.html')
                       
                   }
                   else
                   {
                       console.log('incorrect')
                       alert(" Incorrect username or password")
                   }

               
               
            }
            function registerUser() {
                // store new users username
                var registerUsername = document.getElementById('name').value
                // store new users password
                var registerPassword = document.getElementById('pass').value
                // store new user data in an object
              /* var newUser = {
                    username: registerUsername,
                    password: registerPassword
                } */
                objPeople.push(registerUsername);
                objPeople.push(registerPassword);
                alert("registration successful");
            }